# csesoecusat.github.io
Main Site

	All hail VK, hopefully last of his name, King of the contract puppets and Lord of the Seven Rooms !